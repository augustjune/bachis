# praca_inzynierska_latex
Szablon pracy inżynierskiej na Wydziale Informatyki i Zarządzania (bazujący na szablonie Wojciecha Myszki)

W szablonie wykorzystałem elementy pochodzące z szablonów różnych autorów:
- Wojciech Myszka - układ szablonu, klasa dokumentu itd. z Wydziału Mechanicznego
- Damian Fafuła, Michał Kijaczko, Jakub Michalczak, Maciej Miśta, Dagmara Nowak, Tomasz Skalski, Wojciech Słomian - elementy strony tytułowej szablonu z Wydziału Matematyki
